import type { APIRoute } from "astro";
import { db } from "../../db";
import { users } from "../../db/schema";
import { lucia } from "../../lib/auth";
import { generateId } from "lucia";
import { hash } from "bcryptjs";

export const POST: APIRoute = async ({ request, redirect }) => {
  const formData = await request.formData();
  const username = formData.get("username");
  const email = formData.get("email");
  const password = formData.get("password");

  if (
    typeof username !== "string" ||
    typeof email !== "string" ||
    typeof password !== "string"
  ) {
    return new Response("Invalid input", { status: 400 });
  }

  const userId = generateId(15);
  const hashedPassword = await hash(password, 10);

  try {
    await db.insert(users).values({
      id: userId,
      username,
      email,
      passwordHash: hashedPassword,
    });

    const session = await lucia.createSession(userId, {});
    const sessionCookie = lucia.createSessionCookie(session.id);

    return redirect("/", {
      headers: {
        "Set-Cookie": sessionCookie.serialize(),
      },
    });
  } catch (e) {
    return new Response("Username already taken", { status: 400 });
  }
};