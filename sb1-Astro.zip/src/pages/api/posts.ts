import type { APIRoute } from "astro";
import { db } from "../../db";
import { posts } from "../../db/schema";
import { generateId } from "lucia";

export const POST: APIRoute = async ({ request, locals, redirect }) => {
  const session = await locals.auth.validate();
  if (!session) {
    return new Response("Unauthorized", { status: 401 });
  }

  const formData = await request.formData();
  const content = formData.get("content");

  if (typeof content !== "string" || content.length === 0) {
    return new Response("Invalid content", { status: 400 });
  }

  const postId = generateId(15);

  await db.insert(posts).values({
    id: postId,
    content,
    authorId: session.user.userId,
  });

  return redirect("/");
};