import type { APIRoute } from "astro";
import { db } from "../../db";
import { users } from "../../db/schema";
import { lucia } from "../../lib/auth";
import { eq } from "drizzle-orm";
import { compare } from "bcryptjs";

export const POST: APIRoute = async ({ request, redirect }) => {
  const formData = await request.formData();
  const email = formData.get("email");
  const password = formData.get("password");

  if (typeof email !== "string" || typeof password !== "string") {
    return new Response("Invalid input", { status: 400 });
  }

  const existingUser = await db.query.users.findFirst({
    where: eq(users.email, email),
  });

  if (!existingUser) {
    return new Response("Invalid credentials", { status: 400 });
  }

  const validPassword = await compare(password, existingUser.passwordHash);
  if (!validPassword) {
    return new Response("Invalid credentials", { status: 400 });
  }

  const session = await lucia.createSession(existingUser.id, {});
  const sessionCookie = lucia.createSessionCookie(session.id);

  return redirect("/", {
    headers: {
      "Set-Cookie": sessionCookie.serialize(),
    },
  });
};